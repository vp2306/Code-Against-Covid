# Verifme
View deployed app here: https://stark-earth-94197.herokuapp.com/.

Learn more about app here: https://devpost.com/software/verifme.
